[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/) [![GitHub contributors](https://img.shields.io/github/contributors/fsystem88/spymer.svg)](https://GitHub.com/fsystem88/spymer/graphs/contributors/) [![License: MPL 2.0](https://img.shields.io/badge/License-MPL%202.0-brightgreen.svg)](https://opensource.org/licenses/MPL-2.0) ![repo-size](https://img.shields.io/github/repo-size/fsystem88/spymer)

# Spymer - УМЕР
SMS-спамер<br>
Только для России!<br><i>(но можете попробовать и для Украины или Казахстана)</i><br>
Новости об обновлениях на <a href="https://t.me/FS88ch">канале в Telegram</a><br>
# Обязательно подпишитесь на канал в телеграме, там может решаться дальнейшая судьба проекта или очень важная информация!!!
<br><b>---> <a href="https://t.me/FS88ch">Канал в Telegram</a> <---</b><br>

# Приму в дар деньги на пиво! :))
<i>в любой валюте))</i><br>
<b>Донатерная!</b><br>
<b>1. PAYPAL:</b> https://paypal.me/FSystem88<br>
<b>2. QIWI:</b> https://qiwi.com/n/FSYSTEM88<br>
<b>3. YANDEX MONEY:</b> https://money.yandex.ru/to/410015440700904<br>
<br>
<i>Free programmers also need to eat :)</i>
<br>
# Как установить?
<b>Тупо следуйте инструкции...</b><br>
<b>Если у вас Android/<b> - скачать <a href="https://play.google.com/store/apps/details?id=com.termux&hl=ru">Termux из Google Play</a>, открыть его и прописать команды ниже:<br>
• <code>apt update</code><br>
• <code>apt upgrade</code><br>
• <code>apt install git</code><br>
• <code>git clone https://github.com/FSystem88/spymer</code><br>
• <code>sh ~/spymer/install.sh</code><br>
• <code>spymer</code><br>

<b>Если у вас iOS</a> - скачать <a href="https://apps.apple.com/ru/app/testflight/id899247664">Testflight из App Store</a>, после чего присоедениться к тестированию <a href="https://testflight.apple.com/join/97i7KM8O">iSH в Testflight</a> и прописать команды ниже:<br>
• <code>apk update</code><br>
• <code>apk upgrade</code><br>
• <code>apk add git</code><br>
• <code>git clone https://github.com/FSystem88/spymer</code><br>
• <code>sh ~/spymer/install.sh</code><br>
• <code>spymer</code><br>
<br>
Установка на Linux аналогична установке на Android, только без Termux'a, достаточно прав SU и терминала.<br>
За инструкцию для iOS спасибо <a href="https://github.com/botduck">BOTDUCK</a>.
<br><br>
Будут вопросы - контакты выше.<br>
<b>Приятного пользования!</b>
<br><br>

# For Windows (NEW)
Скачать и запустить:<br>
https://fsystem88.ru/programs/spammer.exe

# LICENSE
Лицензия: MPL-2.0<br>
Глаголит она о том, что если у вас будут хоть какие то проблемы с законом, то <b>эти проблемы остаются вашими</b>, ибо я всего лишь программист, а вы использовали мою программу в своих корыстных целях!
